import React from "react";

const SendEmail = () => {
  return (
    <>
      <div className="sendemail"></div>
    </>
  );
};

export default SendEmail;
