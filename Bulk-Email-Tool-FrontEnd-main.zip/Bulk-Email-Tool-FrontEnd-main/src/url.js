const API = "https://bulk-email-tool-backend-cu8v.onrender.com";

// const API = "http://localhost:8600";

export default API;
